'use strict';
const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const path = require('path');
const { PokerEngine } = require('./lib/poker');
const { WerewolfEngine } = require('./lib/werewolf');
const { ChessEngine } = require('./lib/chess');
const { roomCode: genCode, BOT_AVATARS } = require('./lib/utils');

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });
app.use(express.static(path.join(__dirname, 'public')));
const PORT = process.env.PORT || 3000;

const rooms = new Map();
app.get('/health', (_req, res) => res.status(200).json({ ok: true }));
const ENGINES = { poker: PokerEngine, werewolf: WerewolfEngine, chess: ChessEngine };
const cleanName = n => String(n || '').trim().slice(0, 16) || 'Player';

function fullState(room, viewerId) {
  const base = {
    code: room.code, gameType: room.gameType, variant: room.variant, size: room.size,
    hostId: room.hostId, started: !!room.started, log: room.log.slice(-30), meId: viewerId,
    lobbyPlayers: room.players.map(p => ({ id: p.id, name: p.name, avatar: p.avatar, isBot: p.isBot, connected: p.connected, chips: p.chips })),
  };
  if (room.engine) Object.assign(base, room.engine.publicState(viewerId));
  else base.players = base.lobbyPlayers;
  return base;
}
function broadcast(room) {
  if (!rooms.has(room.code)) return;
  for (const p of room.players) {
    if (!p.isBot && p.connected && p.socketId) io.to(p.socketId).emit('onlineState', fullState(room, p.id));
  }
}
function makeEngine(room) {
  const Cls = ENGINES[room.gameType];
  room.engine = new Cls(room, () => broadcast(room));
}

io.on('connection', socket => {
  console.log(`🔌 ${socket.id} connected`);
  let myRoom = null;
  const me = () => myRoom ? myRoom.players.find(p => p.id === socket.id) : null;

  socket.on('createRoom', (opts, cb) => {
    const gameType = ['poker', 'werewolf', 'chess'].includes(opts.gameType) ? opts.gameType : 'poker';
    let variant = String(opts.variant || 'draw');
    let size = parseInt(opts.size) || 4;
    if (gameType === 'poker') { if (!['draw', 'holdem', 'omaha'].includes(variant)) variant = 'draw'; size = Math.min(10, Math.max(2, size)); }
    if (gameType === 'werewolf') { variant = 'werewolf'; size = Math.min(10, Math.max(5, size)); }
    if (gameType === 'chess') { if (!['standard', 'royale3', 'royale4', 'royale5'].includes(variant)) variant = 'standard'; size = variant === 'standard' ? 2 : parseInt(variant.slice(-1)); }
    let code = genCode(); while (rooms.has(code)) code = genCode();
    const room = { code, gameType, variant, size, hostId: socket.id, players: [], log: [], started: false, engine: null };
    rooms.set(code, room);
    room.players.push({ id: socket.id, socketId: socket.id, name: cleanName(opts.name), avatar: '🧑', isBot: false, connected: true, chips: 1000 });
    room.log.push(`🎲 Room ${code} created for ${gameType}.`);
    myRoom = room; socket.join(code);
    makeEngine(room);
    console.log(`🎲 Room ${code} (${gameType}/${variant}, size ${size}) by ${cleanName(opts.name)}`);
    if (cb) cb({ ok: true, code });
    broadcast(room);
  });

  socket.on('joinRoom', ({ name, code }, cb) => {
    const room = rooms.get(String(code || '').toUpperCase().trim());
    if (!room) { if (cb) cb({ ok: false, error: 'Room not found — check the code.' }); return socket.emit('onlineError', 'Room not found — check the code.'); }
    const maxSeats = room.gameType === 'chess' ? room.size : room.size;
    if (room.players.length >= maxSeats && room.started) { if (cb) cb({ ok: false, error: 'That room is full / already playing.' }); return socket.emit('onlineError', 'That room is full / already playing.'); }
    if (room.players.filter(p => !p.isBot).length >= 10) { if (cb) cb({ ok: false, error: 'Room is full of humans!' }); return socket.emit('onlineError', 'Room is full.'); }
    room.players.push({ id: socket.id, socketId: socket.id, name: cleanName(name), avatar: '🧑', isBot: false, connected: true, chips: 1000 });
    room.log.push(`👋 ${cleanName(name)} joined.`);
    myRoom = room; socket.join(room.code);
    console.log(`🚪 ${cleanName(name)} joined ${room.code}`);
    if (cb) cb({ ok: true, code: room.code });
    broadcast(room);
  });

  socket.on('addBot', () => {
    if (!myRoom || !myRoom.engine) return;
    if (myRoom.engine.addBot()) broadcast(myRoom);
  });
  socket.on('startGame', () => {
    if (!myRoom || myRoom.started || !myRoom.engine) return;
    if (myRoom.gameType === 'poker' && myRoom.players.length < 2) return socket.emit('onlineError', 'Need at least 2 players — add a bot!');
    myRoom.started = true;
    myRoom.engine.start();
    broadcast(myRoom);
  });
  socket.on('gameAction', data => { if (myRoom && myRoom.engine) myRoom.engine.action(socket.id, data || {}); });
  socket.on('playAgain', () => {
    if (!myRoom || !myRoom.engine) return;
    if (myRoom.gameType === 'werewolf' && myRoom.engine.phase === 'over') myRoom.engine.start();
    else if (myRoom.gameType === 'chess' && myRoom.engine.gameOver) { myRoom.engine.started = false; myRoom.engine.start(); }
    else if (myRoom.gameType === 'poker') myRoom.engine.action(socket.id, { type: 'next' });
    broadcast(myRoom);
  });

  socket.on('disconnect', () => {
    if (!myRoom) return;
    const room = myRoom, player = me();
    if (player) {
      player.connected = false;
      room.log.push(`👋 ${player.name} disconnected.`);
      if (room.engine) room.engine.disconnect(socket.id);
      room.players = room.players.filter(p => p.id !== socket.id);
      if (room.hostId === socket.id) { const nh = room.players.find(p => !p.isBot); room.hostId = nh ? nh.id : null; }
      if (!room.players.some(p => !p.isBot)) {
        if (room.engine) room.engine.destroyed = true;
        rooms.delete(room.code);
        console.log(`🗑️ Room ${room.code} closed (empty)`);
        return;
      }
      // if the game can no longer run (e.g. poker <2 humans+bots), keep room as lobby
      broadcast(room);
    }
  });
});

server.listen(PORT, '0.0.0.0', () => console.log(`🎮 Games online server on http://0.0.0.0:${PORT}`));
